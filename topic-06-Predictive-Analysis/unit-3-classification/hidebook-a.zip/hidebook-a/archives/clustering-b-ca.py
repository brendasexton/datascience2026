# -*- coding: utf-8 -*-
"""
Created on Fri May  4 12:17:00 2018

@author: BMULLALLY
"""

from pandas import Series, DataFrame
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.cluster import KMeans
import os 

os.environ["OMP_NUM_THREADS"] = '1'
   

"""
Data Management
"""
data = pd.read_csv("gapminder.csv")

#upper-case all DataFrame column names
data.columns = map(str.upper, data.columns)

# Data Management


data['ARMEDFORCESRATE']=data['ARMEDFORCESRATE'].replace(" ", np.NaN)
data['ARMEDFORCESRATE'] = pd.to_numeric(data['ARMEDFORCESRATE'])
data['LIFEEXPECTANCY']=data['LIFEEXPECTANCY'].replace(" ", np.NaN)
data['LIFEEXPECTANCY'] = pd.to_numeric(data['LIFEEXPECTANCY'])
data['POLITYSCORE']=data['POLITYSCORE'].replace(" ", np.NaN)
data['POLITYSCORE'] = pd.to_numeric(data['POLITYSCORE'])
data['URBANRATE']=data['URBANRATE'].replace(" ", np.NaN)
data['URBANRATE'] = pd.to_numeric(data['URBANRATE'])
data['INTERNETUSERATE']=data['INTERNETUSERATE'].replace(" ", np.NaN)
data['INTERNETUSERATE'] = pd.to_numeric(data['INTERNETUSERATE'])
data['INCOMEPERPERSON']=data['INCOMEPERPERSON'].replace(" ", np.NaN)
data['INCOMEPERPERSON'] = pd.to_numeric(data['INCOMEPERPERSON'])
data_clean = data.dropna()


# subset clustering variables
cluster=data_clean[['ARMEDFORCESRATE','LIFEEXPECTANCY','POLITYSCORE','URBANRATE','INTERNETUSERATE','INCOMEPERPERSON']]
cluster.describe()


# standardize clustering variables to have mean=0 and sd=1
clustervar=cluster.copy()
clustervar['INTERNETUSERATE']=preprocessing.scale(clustervar['INTERNETUSERATE'].astype('float64'))
clustervar['ARMEDFORCESRATE']=preprocessing.scale(clustervar['ARMEDFORCESRATE'].astype('float64'))
clustervar['LIFEEXPECTANCY']=preprocessing.scale(clustervar['LIFEEXPECTANCY'].astype('float64'))
clustervar['POLITYSCORE']=preprocessing.scale(clustervar['POLITYSCORE'].astype('float64'))
clustervar['URBANRATE']=preprocessing.scale(clustervar['URBANRATE'].astype('float64'))

clus_train, clus_test = train_test_split(clustervar, test_size=.3, random_state=123)

from scipy.spatial.distance import cdist
clusters=range(1,10)
meandist=[]
for k in clusters:
    model=KMeans(n_clusters=k, n_init='auto')
    model.fit(clus_train)
    clusassign=model.predict(clus_train)
    meandist.append(sum(np.min(cdist(clus_train, model.cluster_centers_, 'euclidean'), axis=1))
    / clus_train.shape[0])
    

plt.plot(clusters, meandist)
plt.xlabel('Number of clusters')
plt.ylabel('Average distance')
plt.title('Selecting k with the Elbow Method')

#run for 2 clusters only
model2=KMeans(n_clusters=2,  n_init='auto')
model2.fit(clus_train)
clusassign=model2.predict(clus_train)

from sklearn.decomposition import PCA
pca_2 = PCA(2)
plot_columns = pca_2.fit_transform(clus_train)
plt.scatter(x=plot_columns[:,0], y=plot_columns[:,1], c=model2.labels_,)
plt.xlabel('Canonical variable 1')
plt.ylabel('Canonical variable 2')
plt.title('Scatterplot of Canonical Variables for 3 Clusters')
plt.show()

#run for 3 clusters
model3=KMeans(n_clusters=3,  n_init='auto')
model3.fit(clus_train)
clusassign=model3.predict(clus_train)
from sklearn.decomposition import PCA
pca_2 = PCA(2)
plot_columns = pca_2.fit_transform(clus_train)
plt.scatter(x=plot_columns[:,0], y=plot_columns[:,1], c=model3.labels_,)
plt.xlabel('Canonical variable 1')
plt.ylabel('Canonical variable 2')
plt.title('Scatterplot of Canonical Variables for 4 Clusters')
plt.show()

#work on cluster assignment with clustering variables to examine means by cluster.

#create a unique identifier variable from the index for the 
#cluster training data to merge with the cluster assignment variable
clus_train.reset_index(level=0, inplace=True)

#create a list that has the new index variable.
cluslist=list(clus_train['index'])
cluslist

#create a list of cluster assignments
labels=list(model2.labels_)
labels

#combine index variable list with cluster assignment list into a dictionary
newlist=dict(zip(cluslist, labels))
newlist

#convert newlist dictionary to a dataframe
newclus=DataFrame.from_dict(newlist, orient='index')
newclus.head(25)


#now do the same for the cluster assignment variable 
#rename the cluster assignment column
newclus.columns=['cluster']

#create a unique identifier variable from the index for the
#cluster assignment dataframe
#to merge with cluster training data
newclus.reset_index(level=0, inplace=True)

#merge cluster assignment dataframe with the cluster training variable dataframe#
#by the index variable

merged_train=pd.merge(clus_train, newclus, on='index')
merged_train.head(20)

#cluster frequencies written two different ways
merged_train['cluster'].value_counts()
merged_train.cluster.value_counts()

#finally calculate clustering variable means by cluster
clustergrp = merged_train.groupby('cluster').mean()
print('Clustering variable means by cluster')
print(clustergrp)

#Cluster 0 shows low scores for lifeexpectancy, polity score, urbanrate and internet use rate.
#Cluster 1 shows higher scores for all variables compared to cluster 0 



#We first have to extract the income per person from the original data set, 

#we  create a new dataframe that only contains the two columns GPA1 and cluster
#with any rows that have NAN's removed.
sub1=merged_train[['INCOMEPERPERSON','cluster']].dropna()

#We'll use analysis of variance to test whether there are significant differences 
#between clusters on the quantitative GPA variable.

#first we have to import in the statsmodels.formula.api and the 
#statsmodels.stats.multicomp libraries. We use the ols function to test the
# analysis of variance (ANOVA).

import statsmodels.formula.api as smf
import statsmodels.stats.multicomp as multi

#remember the response variable goes first and then any catagory variables are 
#noted by the 'C'
gpamod = smf.ols(formula='INCOMEPERPERSON ~ C(cluster)',data=sub1).fit()
print(gpamod.summary())

#We can also print the mean GPA and standard deviation for each cluster using the 
#groupby function.

print('means by INCOMEPERPERSON by cluster')
m1=sub1.groupby('cluster').mean()
print(m1)

print('std deviations by cluster')
m2=sub1.groupby('cluster').std()
print(m2)


# Then, because our categorical cluster variable has three categories,
# we will request a tukey test to evaluate post hot comparisons between the clusters 
#using the multi comparison function from the statsmodels.stats.multicomplibrary 
#which we imported as multi.

mc1= multi.MultiComparison(sub1['INCOMEPERPERSON'],sub1['cluster']) 
res1=mc1.tukeyhsd()
print(res1.summary())

# Here are the results. 
#The analysis of variance summary table indicates that the clusters differed 
#significantly on INCOMEPERPERON. When we examine the means, we find that not surprisingly, 
#countries in cluster 1,  had the lowest INCOMPERPERSON, and 
#countries in cluster 0, had the highest INCOMEPERPERON. 
#The tukey test shows that the clusters differed significantly in mean INCOMPERPERSON,




